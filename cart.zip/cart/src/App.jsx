

import React from 'react'
import './App.css'
import MainPage from './shoppingfolder/pages/MainPage'


const App = () => {
  return (
    <div>
      <MainPage />
      
    </div>
  )
}

export default App
