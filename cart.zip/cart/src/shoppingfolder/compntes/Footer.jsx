

import React from 'react'

const Footer = () => {
  return (
    <div>
      <img src="/assets/footer.png"/>
    </div>
  )
}

export default Footer
