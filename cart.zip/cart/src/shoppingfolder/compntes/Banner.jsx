

import React from 'react'

const Banner = () => {
  return (
    <div className='bannerSection'>
        <div className='bannerbox'>

        <img alt="Banner" src="/assets/banner01.png"/>
        
        </div>
      
    </div>
  )
}

export default Banner
